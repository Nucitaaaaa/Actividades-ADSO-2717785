from django.apps import AppConfig


class Actividad1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'actividad1'
